import java.util.*;

public class No1 {

	public static void main(String[] args) {
		
		Solution1 sol = new Solution1();
		int[] s = {1, 0, 0, 1, 1,0,0,0,0,0,0,0,0,0,0,0,0,0};
		
		
		
		
		
	}
	
	
	
}

class Solution1 {
    public int[] solution(String[] id_list, String[] report, int k) {
        int[] answer = new int[id_list.length];
        
        Map<String, User> user = new HashMap<String, User>();
        
        for (int i = 0; i < id_list.length; i++) {
			user.put(id_list[i], new User(id_list[i]));
		}
        
        for (int i = 0; i < report.length; i++) {
			String[] r = report[i].split(" ");
        	if(!user.get(r[1]).reporter.contains(r[0])) {
        		user.get(r[1]).reported++;
        		user.get(r[1]).reporter.add(r[0]);
        	}
		}
        
        for (String id : user.keySet()) {
			if(user.get(id).reported >= k) {
				for (String mailed_id : user.get(id).reporter) {
					user.get(mailed_id).mailed++;
				}
			}
		}
        
        for (int i = 0; i < answer.length; i++) {
			answer[i] = user.get(id_list[i]).mailed;
		}
        
        return answer;
    }
}

class User {
	String id;
	int reported = 0;
	int mailed = 0;
	Set<String> reporter = new HashSet<String>();
	User(String s){
		id = s;
	}
}