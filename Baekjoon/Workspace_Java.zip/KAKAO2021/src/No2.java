import java.util.*;

public class No2 {

	public static void main(String[] args) {
		
		Solution2 sol = new Solution2();
		
		int answer  = sol.solution(2318794, 7);
		System.out.println(answer);
		
	}
	
	
	
}


class Solution2 {
	
    public int solution(int n, int k) {
        
        String toK = toKnary(n, k);

		List<String> list = new ArrayList<String>();
//    	String[] splitZero = toK.split("0");

		StringBuilder sb = new StringBuilder();

		for (int i = 0; i < toK.length(); i++) {
			if(toK.charAt(i) == '0') {
				if(sb.length()==0)continue;
				list.add(sb.toString());
				sb.delete(0, sb.length());
			}else {
				sb.append(toK.charAt(i));
			}
		}
		if(sb.length()>0) {
			list.add(sb.toString());
		}

    	
        long[] num = new long[list.size()];
        for (int i = 0; i < num.length; i++) {
        	
        	num[i] = Long.parseLong(list.get(i));				
			
		}
        
        int answer = 0;
        for (int i = 0; i < num.length; i++) {
			if(isPrime(num[i])) answer++;
		}
        
        
        return answer;
    }
    
    public boolean isPrime(long n) {
    	if(n==1) return false;
    	int fin = (int) Math.sqrt(n);
    	for (int i = 2; i < fin; i++) {
			if(n % i == 0) return false;
		}
    	return true;
    }
    
    public String toKnary(int n, int k) {
    	StringBuilder sb = new StringBuilder();
    	while(n != 0) {
    		sb.append(n%k);
    		n/=k;
    	}
    	return sb.reverse().toString();
    }
}