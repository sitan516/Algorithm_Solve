import java.util.*;

public class No3 {

	public static void main(String[] args) {
		
		Solution3 sol = new Solution3();
		int[] fees = {180, 5000, 10, 600};
		String[] r = {"05:34 5961 IN", "06:00 0000 IN", "06:34 0000 OUT", "07:59 5961 OUT", "07:59 0148 IN", "18:59 0000 IN", "19:09 0148 OUT", "22:59 5961 IN", "23:00 5961 OUT"};
		int[] answer  = sol.solution(fees, r);
		for (int i = 0; i < answer.length; i++) {
			System.out.println(answer[i]);
		}
		
	}
	
	
	
}


class Solution3 {
    public int[] solution(int[] fees, String[] records) {
        
        
        Car.standardTime = fees[0];
        Car.standardCharge = fees[1];
        Car. unitTime = fees[2];
        Car. unitCharge = fees[3];
        
        Map<String, Car> cars = new HashMap<String, Car>();
        
        for (int i = 0; i < records.length; i++) {
			String[] part = records[i].split(" ");
			String[] partTime = part[0].split(":");
			int time = Integer.parseInt(partTime[0])*60 + Integer.parseInt(partTime[1]);
			int carNum = Integer.parseInt(part[1]);
			
        	if("IN".equals(part[2])) {
        		if(cars.containsKey(part[1])) {
        			cars.get(part[1]).inCar(time);
        			
        		}else {
        			cars.put(part[1], new Car(carNum));
        			cars.get(part[1]).inCar(time);
        		}
        	}else {
        		cars.get(part[1]).outCar(time);
        	}
		}
        
        for (String s : cars.keySet()) {
			if(cars.get(s).isParking) {
				cars.get(s).setSumTime();
			}
		}
        
        
        List<Car> carList = new ArrayList<>(cars.values());
        Collections.sort(carList);
        
        int[] answer = new int[carList.size()];
        
        for (int i = 0; i < answer.length; i++) {
			answer[i] = carList.get(i).getCharge();
		}
        
        return answer;
    }
    
    
    
    
}	

class Car implements Comparable<Car>{
	static int standardTime;
	static int standardCharge;
	static int unitTime;
	static int unitCharge;

	int num;
	int in;
	int out = 23*60 + 59;
	int sumTime = 0;
	boolean isParking = false;
	
	public Car(int num) {
		this.num = num;
	}
	
	void inCar(int in) {
		isParking = true;
		this.in = in;
		this.out = 23*60 + 59;
	}
	
	void outCar(int out) {
		isParking = false;
		this.out = out;
		setSumTime();
	}
	
	void setSumTime(){
    	int time = out-in;
    	sumTime += time;
    }
	
	int getCharge() {
    	if(sumTime <= standardTime ) {
			return standardCharge;
		}else {
			int overCharge = (int) Math.ceil((double)(sumTime - standardTime) / unitTime) * unitCharge;
			return standardCharge + overCharge;
		}
	}
	
	@Override
	public int compareTo(Car o) {
		return this.num - o.num;
	}
}
