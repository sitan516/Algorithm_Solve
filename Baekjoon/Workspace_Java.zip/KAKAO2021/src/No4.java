import java.util.*;

public class No4 {

	public static void main(String[] args) {
		
		Solution4 sol = new Solution4();
		
		int[] r = {1,0,0,0,0,0,0,0,0,0,0};
		
		int[] answer  = sol.solution(1,r);
		for (int i = 0; i < answer.length; i++) {
			System.out.println(answer[i]);
		}
		
	}
	
	
	
}




class Solution4 {

	// 각 과녁마다 몇개 -> 몇점 인지
	// 이후 고르자
	
    public int[] solution(int n, int[] info) {
        
    	int apeachScore = 0;
    	
        int[] score = new int[11];
        for (int i = 0; i < score.length; i++) {
			score[i] = (10-i);
			if(info[i] != 0) {
				score[i] *= 2;
				apeachScore += (10-i);
			}
		}
        
        int bitmask[] = new int[n+1];
        int max[] = new int[n+1];
        Arrays.fill(max, -1);
        max[0] = 0;
        
        for (int i = 10; i >= 0; i--) {
			for (int j = n; j >= info[i]+1; j--) {
				if(max[j-(info[i]+1)] != -1) {
					if(max[j] <= max[j-(info[i]+1)] + score[i]) {
						
						if(max[j] == max[j-(info[i]+1)] + score[i]) {
							if(bitmask[j] > bitmask[j-(info[i]+1)]) {
								continue;
							}
						}
						
						max[j] = max[j-(info[i]+1)] + score[i];
						bitmask[j] = bitmask[j-(info[i]+1)] | 1 << i;
					}
				}
			}
		}
        
        int maxDiff = 0;
        int idx = -1;
        for (int i = 0; i <= n; i++) {
			if(maxDiff < max[i]) {
				maxDiff = max[i];
				idx = i;
			}
		}
        
        if(apeachScore >= maxDiff) {
        	int[] ret = {-1}; 
        	return ret;
        }
        
        
        int[] answer = new int[11];
        for (int i = 0; i < 11; i++) {
			if((bitmask[idx] & 1<<i) != 0) {
				answer[i] = info[i] + 1;
			}
		}
        
        if(idx < n) {
        	answer[10] += n-idx;
        }
        
        return answer;
    }
    
    int getHighestBit(int n) {
    	return Integer.highestOneBit(n);
    }
}