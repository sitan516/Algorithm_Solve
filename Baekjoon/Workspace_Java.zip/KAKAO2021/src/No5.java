import java.util.*;

public class No5 {

	public static void main(String[] args) {
		
		Solution5 sol = new Solution5();
		int[] info = {0,0,1,1,1,0,1,0,1,0,1,1};
		int[][] edges = {{0,1},{1,2},{1,4},{0,8},{8,7},{9,10},{9,11},{4,3},{6,5},{4,6},{8,9}};
		int answer  = sol.solution(info, edges);
		System.out.println(answer);
		
	}
	
	
	
}



class Solution5 {
	static int N;
	static Node[] nodes;
    public int solution(int[] info, int[][] edges) {
        
        N = info.length;
        nodes = new Node[info.length];
        
        for (int i = 0; i < nodes.length; i++) {
			nodes[i] = new Node(i, info[i]);
		}
        
        for (int i = 0; i < edges.length; i++) {
			nodes[edges[i][0]].next.add(nodes[edges[i][1]]);
		}
        
        int startBitmask = 0;
        for (Node node : nodes[0].next) {
        	startBitmask |= 1 << node.idx;
		}
        
        int answer = move(1, 0, startBitmask);
        
        return answer;
    }
    public int move(int sheep, int wolf, int bitmask) {
    	
    	if(sheep == wolf) return -1;
    	int maxSheep = sheep;
    	for (int i = 0; i < N; i++) {
			if((bitmask & 1<<i) != 0) {
				int newBitmask = bitmask - (1<<i);
				for (Node node : nodes[i].next) {
		        	newBitmask |= 1 << node.idx;
				}
				maxSheep = Math.max(maxSheep, move(nodes[i].sheep?sheep+1:sheep, nodes[i].sheep?wolf:wolf+1, newBitmask));
			}
		}
    	
    	return maxSheep;
    }
}

class Node{
	int idx;
	boolean sheep;

	Set<Node> next = new HashSet<Node>();
	Node(int idx, int i){
		this.idx = idx;
		sheep = i==0? true: false;
	}
}