import java.util.*;

public class No6 {

	public static void main(String[] args) {
		
		Solution6 sol = new Solution6();
		int[][] board = {{5,5,5,5,5},{5,5,5,5,5},{5,5,5,5,5},{5,5,5,5,5}};
		int[][] edges = {{1,0,0,3,4,4},{1,2,0,2,3,2},{2,1,0,3,1,2},{1,0,1,3,3,1}};
		int answer  = sol.solution(board, edges);
		System.out.println(answer);
		
	}
	
	
	
}



class Solution6 {
    public int solution(int[][] board, int[][] skill) {
        int answer = 0;
        
        int N = board.length;
        int M = board[0].length;
        
        int[][] preSum = new int[N*(N-1)/2][M];
        
        for (int i = 0; i < skill.length; i++) {
			int r = skill[i][1] * N + skill[i][3];
			int c1 = skill[i][2];
			int c2 = skill[1][4];
        	for (int c = c1; c <= c2; c++) {
				preSum[r][c] += (skill[i][0]*2-3) * skill[i][5];
			}
		}
        
        for (int i = 0; i < preSum.length; i++) {
			for (int j = 0; j < M; j++) {
				
			}
		}
        
        
        
//        for (int i = 0; i < skill.length; i++) {
//        	if(skill[i][0] == 1) {
//        		doit(-skill[i][5] , skill[i][1],skill[i][2],skill[i][3],skill[i][4],board);        		
//        	}else {
//        		doit(skill[i][5] , skill[i][1],skill[i][2],skill[i][3],skill[i][4],board);
//        	}
//		}
//        
//        for (int r = 0; r < board.length; r++) {
//			for (int c = 0; c < board[0].length; c++) {
//				if(board[r][c] > 0) answer++;
//			}
//		}
        
        return answer;
    }
    
    public void doit(int damage, int r1, int c1, int r2, int c2, int[][] board) {
    	for (int r = r1; r <= r2; r++) {
			for (int c = c1; c <= c2; c++) {
				board[r][c] += damage;
			}
		}
    }
}