import java.util.*;

public class No7 {

	public static void main(String[] args) {
		
		Solution7 sol = new Solution7();
		int[][] board = {{1, 1, 1}, {1, 1, 1}, {1, 1, 1}};
		int[] aloc = {1,0};
		int[] bloc = {1,2};
		
		int answer  = sol.solution(board, aloc, bloc);
		System.out.println(answer);
		
	}
	
	
	
}


// 패배자는 버틸 수 있는 만큼
// 승리자는 가능한 빠르게

// 상대방이 서있는 곳은 안간다.
// 하지만 가는 칸 주위에 갈 수 있는 곳이 없으면 확정킬

// BFS 로 갈수 있는 길 찾고
// 먼저 겹치면 짐

//========================

// 분쟁지역 : 갈 수 있는 최소거리가 같은 지역
// 내 구역 : 갈 수 있는 최소거리가 겹치지 않는 지역

class Solution7 {
	static int[][] board;
	static int[][][] abBFS;
	static int[][][] bitmask;
	static int[] dx = {1,-1,0,0};
	static int[] dy = {0,0,1,-1};
	static int N;
	static int M;
	Queue<Position> q;
    public int solution(int[][] board, int[] aloc, int[] bloc) {
        int answer = -1;
        this.board = board;
        N = board.length;
        M = board[0].length;
        abBFS = new int[2][N][M];
        bitmask = new int[2][N][M];
        
        for (int i = 0; i < bloc.length; i++) {
			Arrays.fill(abBFS[0][i], -1);
			Arrays.fill(abBFS[1][i], -1);
		}
        
        q = new LinkedList<Position>();
        q.add(new Position(aloc[0], aloc[1], 0, 0));
        q.add(new Position(bloc[0], bloc[1], 0, 1));
        abBFS[0][aloc[0]][aloc[1]] = 0;
        abBFS[0][bloc[0]][bloc[1]] = 0;
        
        while(!q.isEmpty()) {
        	Position pos = q.poll();
        	BFS(pos);
        }
        
        int maxA = 0;
        int maxB = 0;
        for (int r = 0; r < N; r++) {
			for (int c = 0; c < M; c++) {
				maxA = Math.max(abBFS[0][r][c], maxA);
				maxB = Math.max(abBFS[1][r][c], maxB);
			}
		}
		
		// max가 더 큰 사람이 우승
		
		// max가 같다면?
        
        
        return answer;
    }
    
    public void BFS(Position pos) {
    	for (int d = 0; d < 4; d++) {
			int newR = pos.r + dy[d];
			int newC = pos.r + dy[d];
			
			if(board[newR][newC] == 1 
					&& (abBFS[0][newR][newC] == -1 || abBFS[0][newR][newC] == pos.cost+1) 
					&& (abBFS[1][newR][newC] == -1 || abBFS[1][newR][newC] == pos.cost+1)) {
				abBFS[pos.player][newR][newC] = pos.cost+1;
				q.add(new Position(newR, newC, pos.cost+1, pos.player));
			}
		}
    }
}

class Position{
	int r;
	int c;
	int cost;
	int player;
	public Position(int r, int c, int cost, int player) {
		super();
		this.r = r;
		this.c = c;
		this.cost = cost;
		this.player = player;
	}
	
}