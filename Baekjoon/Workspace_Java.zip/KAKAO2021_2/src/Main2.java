import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.json.JSONArray;
import org.json.JSONObject;

public class Main2 {
	
	final static String BASE_URL = "https://huqeyhi95c.execute-api.ap-northeast-2.amazonaws.com/prod";
	final static String X_AUTH_TOKEN = "f17eb6ec1719ab64a2c96805ccd5619b";
	
	static String authKey;
	
	static Map<Integer, User2> users = new HashMap<Integer, User2>();
	
	public static void main(String[] args) {
		authKey = RestApi.start(2);
		
		JSONObject usersJson = RestApi.getUserInfo(authKey);
		JSONArray usersJsonArray = usersJson.getJSONArray("user_info");
		JSONArray commands = new JSONArray();

		for (int i = 0; i < usersJsonArray.length(); i++) {
			JSONObject userJson = usersJsonArray.getJSONObject(i);
			JSONObject command = new JSONObject();
			User2 newUser = new User2(userJson.getInt("id"), 4000);
			users.put(newUser.getId(), newUser);
			command.put("id", userJson.getInt("id"));
			command.put("grade", 4000);
			commands.put(command);
		}
		
		RestApi.changeGrade(authKey, commands);
		
		
		for (int t = 1; t <= 596; t++) {
			turn();
		}
		
		JSONObject score = RestApi.score(authKey);
		System.out.println(score.toString());
		
	}
	
	
	public static void turn() {
		
		
		// Game Result 받아오기
		doGameResult();
		
		// 대기자 받아오기
		List<User2> waitingUsers = doWaitingList(); 
		
		// 매칭 시키기
		doMatch(waitingUsers);
		
	}
	
	private static void doMatch(List<User2> waitingUsers) {
		JSONArray pairs = new JSONArray();
		
		Collections.sort(waitingUsers);
		bigLoop : for (int i = 0; i < waitingUsers.size(); i++) {
			for (int j = i+1; j < waitingUsers.size(); j++) {
				if(waitingUsers.get(i).isMatched()) continue bigLoop;
				if(waitingUsers.get(j).isMatched()) continue;
				if(waitingUsers.get(i).getEnd() >= waitingUsers.get(j).getStart()) {
					waitingUsers.get(i).setMatched(true);
					waitingUsers.get(j).setMatched(true);
					int[] pair = {waitingUsers.get(i).getId(),waitingUsers.get(j).getId()};
					pairs.put(pair);
				}
			}
		}
		
		RestApi.match(authKey, pairs);
	}


	private static List<User2> doWaitingList() {
		List<User2> waitingUsers = new ArrayList<User2>();
		JSONObject waitingListJson = RestApi.getWaitingLine(authKey);
		JSONArray waitingListJsonArray = waitingListJson.getJSONArray("waiting_line");
		
		//5000 + from * 200 으로 싸우기 에서 겹치면 싸우기
		for (int i = 0; i < waitingListJsonArray.length(); i++) {
			JSONObject waitingJson = waitingListJsonArray.getJSONObject(i);
			int id = waitingJson.getInt("id");
			int from = waitingJson.getInt("from");
			User2 targetUser = users.get(id);
			targetUser.setFrom(from);
			targetUser.setMatched(false);
			waitingUsers.add(targetUser);
		}
		return waitingUsers;
	}


	public static void doGameResult() {
		JSONObject gameResultsJson = RestApi.getGameResult(authKey);
		JSONArray gameResultsJsonArray = gameResultsJson.getJSONArray("game_result");
		JSONArray commands = new JSONArray();
		for (int i = 0; i < gameResultsJsonArray.length(); i++) {
			JSONObject gameResultJson = gameResultsJsonArray.getJSONObject(i);
			int win = gameResultJson.getInt("win");
			int lose = gameResultJson.getInt("lose");
			int taken = gameResultJson.getInt("taken");
			
			int dif = (40 - taken) * 283;
			
			User2 winner = users.get(win);
			User2 loser = users.get(lose);
			
			int mid = (winner.getGrade() + loser.getGrade())/2;
			
			if(winner.getGrade() < loser.getGrade()) {
				loser.addGameWithUnderRating();
			}else if(winner.getGrade() > loser.getGrade()) {
				winner.addGameWithUnderRating();
			}
			
			// 10분 이하 처리
			if(taken<= 10) {
				loser.addUnderTen();
				if(winner.getGrade() < loser.getGrade()) {
					loser.addUpset();
				}
				loser.addUpsetUser(winner);
				loser.addUpsetScore(dif/2);
			}
		
			loser.addGame();
			winner.addGame();
			
			// 어뷰저 검사
//			if((loser.getUpset() >= 3 && loser.getUpset()*2 > loser.getGameWithUnderRating() && !loser.isAbuse()) ||
//					(loser.getUnderTen() >= 3 && loser.getUnderTen()*3 > loser.getGame() && !loser.isAbuse())) {
//				loser.setAbuse(true);
//				List<User2> victims = loser.getUpsetUser();
//				List<Integer> scores = loser.getUpsetScore();
//				for (int j = 0; j < victims.size(); j++) {
//					victims.get(j).addGrade(-scores.get(j)/2);
//					loser.addGrade(scores.get(j)/2);
//				}
//			}
			
			if((winner.getGrade() < loser.getGrade()) && taken <= 10 && loser.isAbuse()) {
				return;
			}
			
			winner.setGrade(mid+dif/2);
			loser.setGrade(mid-dif/2);			
			
			JSONObject command = new JSONObject();
			command.put("id", win);
			command.put("grade", users.get(win).getGrade());
			commands.put(command);
			command = new JSONObject();
			command.put("id", lose);
			command.put("grade", users.get(lose).getGrade());
			commands.put(command);
		}
		
		RestApi.changeGrade(authKey, commands);

	}
	
}
