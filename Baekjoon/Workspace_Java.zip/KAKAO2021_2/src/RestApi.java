import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

public class RestApi {
	
	final static String BASE_URL = "https://huqeyhi95c.execute-api.ap-northeast-2.amazonaws.com/prod";
	final static String X_AUTH_TOKEN = "f17eb6ec1719ab64a2c96805ccd5619b";
	
	public static String start(int num){
		HttpURLConnection conn = null;
        JSONObject responseJson = null;
        
        try {
        	URL url = new URL(BASE_URL+"/start");
        	conn = (HttpURLConnection) url.openConnection();
        	conn.setRequestMethod("POST");
        	conn.setRequestProperty("Content-Type", "application/json");
        	conn.setRequestProperty("X-Auth-Token", X_AUTH_TOKEN);
        	conn.setDoOutput(true);
        	
        	BufferedWriter bw = new BufferedWriter(new OutputStreamWriter(conn.getOutputStream()));
        	JSONObject params = new JSONObject();
        	params.put("problem", num);

            bw.write(params.toString());
            bw.flush();
            bw.close();

        	int responseCode = conn.getResponseCode();
        	if(responseCode == 200) {
	    		BufferedReader br = new BufferedReader(new InputStreamReader(conn.getInputStream()));
	            StringBuilder sb = new StringBuilder();
	            String line = "";
	            while ((line = br.readLine()) != null) {
	                sb.append(line).append("\n");
	            }
	            responseJson = new JSONObject(sb.toString());
	            return responseJson.get("auth_key").toString();
        	} else {
        		return null;
        	}
        	
        }catch(Exception e) {
        	e.printStackTrace();
        	
        }
        
        return "";
	}
	
	public static JSONObject getWaitingLine(String authKey){
		HttpURLConnection conn = null;
        JSONObject responseJson = null;
        
        try {
        	URL url = new URL(BASE_URL+"/waiting_line");
        	conn = (HttpURLConnection) url.openConnection();
        	conn.setRequestMethod("GET");
        	conn.setRequestProperty("Content-Type", "application/json");
        	conn.setRequestProperty("Authorization", authKey);
//        	conn.setDoOutput(false);

        	
        	int responseCode = conn.getResponseCode();
        	if(responseCode == 200) {
	    		BufferedReader br = new BufferedReader(new InputStreamReader(conn.getInputStream()));
	            StringBuilder sb = new StringBuilder();
	            String line = "";
	            while ((line = br.readLine()) != null) {
	                sb.append(line).append("\n");
	            }
	            responseJson = new JSONObject(sb.toString());
        	} else {
        		return null;
        	}
        	
        }catch(Exception e) {
        	e.printStackTrace();
        	
        }
        
        return responseJson;
	}
	
	public static JSONObject getUserInfo(String authKey){
		HttpURLConnection conn = null;
        JSONObject responseJson = null;
        
        try {
        	URL url = new URL("https://huqeyhi95c.execute-api.ap-northeast-2.amazonaws.com/prod/user_info");
        	
        	conn = (HttpURLConnection) url.openConnection();
        	conn.setRequestMethod("GET");
        	conn.setRequestProperty("Content-Type", "application/json");
        	conn.setRequestProperty("Authorization", authKey);
        	conn.setDoOutput(true);

        	int responseCode = conn.getResponseCode();
        	if(responseCode == 200) {
	    		BufferedReader br = new BufferedReader(new InputStreamReader(conn.getInputStream()));
	            StringBuilder sb = new StringBuilder();
	            String line = "";
	            while ((line = br.readLine()) != null) {
	                sb.append(line).append("\n");
	            }
	            responseJson = new JSONObject(sb.toString());
        	} else {
        		BufferedReader br = new BufferedReader(new InputStreamReader(conn.getInputStream()));
	            StringBuilder sb = new StringBuilder();
	            String line = "";
	            while ((line = br.readLine()) != null) {
	                sb.append(line).append("\n");
	            }
        		return null;
        	}
        	
        }catch(Exception e) {
        	e.printStackTrace();
        	
        }
        
        return responseJson;
	}
	
	public static JSONObject getGameResult(String authKey){
		HttpURLConnection conn = null;
        JSONObject responseJson = null;
        
        try {
        	URL url = new URL("https://huqeyhi95c.execute-api.ap-northeast-2.amazonaws.com/prod/game_result");
        	
        	conn = (HttpURLConnection) url.openConnection();
        	conn.setRequestMethod("GET");
        	conn.setRequestProperty("Content-Type", "application/json");
        	conn.setRequestProperty("Authorization", authKey);
        	conn.setDoOutput(true);

        	int responseCode = conn.getResponseCode();
        	if(responseCode == 200) {
	    		BufferedReader br = new BufferedReader(new InputStreamReader(conn.getInputStream()));
	            StringBuilder sb = new StringBuilder();
	            String line = "";
	            while ((line = br.readLine()) != null) {
	                sb.append(line).append("\n");
	            }
	            responseJson = new JSONObject(sb.toString());
        	} else {
        		BufferedReader br = new BufferedReader(new InputStreamReader(conn.getInputStream()));
	            StringBuilder sb = new StringBuilder();
	            String line = "";
	            while ((line = br.readLine()) != null) {
	                sb.append(line).append("\n");
	            }
        		return null;
        	}
        	
        }catch(Exception e) {
        	e.printStackTrace();
        	
        }
        
        return responseJson;
	}
	
	public static JSONObject changeGrade(String authKey, JSONArray commands){
		HttpURLConnection conn = null;
        JSONObject responseJson = null;
        
        try {
        	URL url = new URL(BASE_URL+"/change_grade");
        	conn = (HttpURLConnection) url.openConnection();
        	conn.setRequestMethod("PUT");
        	conn.setRequestProperty("Content-Type", "application/json");
        	conn.setRequestProperty("Authorization", authKey);
        	conn.setDoOutput(true);
        	
        	BufferedWriter bw = new BufferedWriter(new OutputStreamWriter(conn.getOutputStream()));
        	JSONObject params = new JSONObject();
        	params.put("commands", commands);

            bw.write(params.toString());
            bw.flush();
            bw.close();

        	int responseCode = conn.getResponseCode();
        	if(responseCode == 200) {
	    		BufferedReader br = new BufferedReader(new InputStreamReader(conn.getInputStream()));
	            StringBuilder sb = new StringBuilder();
	            String line = "";
	            while ((line = br.readLine()) != null) {
	                sb.append(line).append("\n");
	            }
	            responseJson = new JSONObject(sb.toString());
        	} else {
        		return null;
        	}
        	
        }catch(Exception e) {
        	e.printStackTrace();
        	
        }
        
        return responseJson;
	}
	
	
	public static JSONObject match(String authKey, JSONArray pairs){
		HttpURLConnection conn = null;
        JSONObject responseJson = null;
        
        try {
        	URL url = new URL(BASE_URL+"/match");
        	conn = (HttpURLConnection) url.openConnection();
        	conn.setRequestMethod("PUT");
        	conn.setRequestProperty("Content-Type", "application/json");
        	conn.setRequestProperty("Authorization", authKey);
        	conn.setDoOutput(true);
        	System.out.println(pairs.toString());
        	BufferedWriter bw = new BufferedWriter(new OutputStreamWriter(conn.getOutputStream()));
        	JSONObject params = new JSONObject();
        	params.put("pairs", pairs);

            bw.write(params.toString());
            bw.flush();
            bw.close();

        	int responseCode = conn.getResponseCode();
        	if(responseCode == 200) {
	    		BufferedReader br = new BufferedReader(new InputStreamReader(conn.getInputStream()));
	            StringBuilder sb = new StringBuilder();
	            String line = "";
	            while ((line = br.readLine()) != null) {
	                sb.append(line).append("\n");
	            }
	            responseJson = new JSONObject(sb.toString());
	            System.out.println(sb.toString());
        	} else {
        		return null;
        	}
        	
        }catch(Exception e) {
        	e.printStackTrace();
        	
        }
        
        return responseJson;
	}
	
	
	public static JSONObject score(String authKey){
		HttpURLConnection conn = null;
        JSONObject responseJson = null;
        
        try {
        	URL url = new URL(BASE_URL+"/score");
        	conn = (HttpURLConnection) url.openConnection();
        	conn.setRequestMethod("GET");
        	conn.setRequestProperty("Content-Type", "application/json");
        	conn.setRequestProperty("Authorization", authKey);

        	int responseCode = conn.getResponseCode();
        	if(responseCode == 200) {
	    		BufferedReader br = new BufferedReader(new InputStreamReader(conn.getInputStream()));
	            StringBuilder sb = new StringBuilder();
	            String line = "";
	            while ((line = br.readLine()) != null) {
	                sb.append(line).append("\n");
	            }
	            responseJson = new JSONObject(sb.toString());
        	} else {
        		return null;
        	}
        	
        }catch(Exception e) {
        	e.printStackTrace();
        	
        }
        
        return responseJson;
	}
	
}
