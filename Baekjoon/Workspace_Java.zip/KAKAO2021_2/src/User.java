
public class User implements Comparable<User>{
	private int id;
	private int grade;
	private int from;
	private boolean matched;
	
	
	
	public boolean isMatched() {
		return matched;
	}
	public void setMatched(boolean matched) {
		this.matched = matched;
	}
	public User(int id, int grade) {
		super();
		this.id = id;
		this.grade = grade;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public int getGrade() {
		return grade;
	}
	public void setGrade(int grade) {
		if(grade >= 10000) {
			grade = 9999;
		}else if(grade < 1) {
			grade = 1;
		}
		this.grade = grade;
	}
	
	public void addGrade(int score) {
		grade += score;
		if(grade >= 10000) {
			grade = 9999;
		}else if(grade < 1) {
			grade = 1;
		}
	}
	
	public int getFrom() {
		return from;
	}
	public void setFrom(int from) {
		this.from = from;
	}
	@Override
	public int compareTo(User o) {
		return this.grade - o.grade;
	}
	
	public int getStart() {
		return grade-400-from*100;
	}
	public int getEnd() {
		return grade+400+from*100;
	}
	
}
