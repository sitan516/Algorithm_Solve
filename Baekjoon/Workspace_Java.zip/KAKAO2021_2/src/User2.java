import java.util.ArrayList;
import java.util.List;

public class User2 implements Comparable<User2>{
	private int id;
	private int grade;
	private int from;
	private boolean matched;
	private int upset = 0; // 낮은 레이팅한테 10분안에 짐
	private int gameWithUnderRating = 0;
	private int game = 0; // 게임한 횟수
	private int underTen = 0; 
	
	private boolean abuse = false;
	private List<User2> upsetUser = new ArrayList<User2>();
	private List<Integer> upsetScore = new ArrayList<Integer>();
	// upset수가  3회 이상, upset/game = 0.5 이상 이면 어뷰져
	// game수 대비 진
	// 어뷰저가 낮은 레이팅과 해서 지는건 무시
	
	
	
	public int getGameWithUnderRating() {
		return gameWithUnderRating;
	}
	public void addGameWithUnderRating() {
		gameWithUnderRating++;
	}
	public int getUnderTen() {
		return underTen;
	}
	public void addUnderTen() {
		underTen++;
	}
	
	public List<User2> getUpsetUser() {
		return upsetUser;
	}
	public void addUpsetUser(User2 user) {
		upsetUser.add(user);
	}
	public List<Integer> getUpsetScore() {
		return upsetScore;
	}
	public void addUpsetScore(int score) {
		upsetScore.add(score);
	}
	public boolean isAbuse() {
		return abuse;
	}
	public void setAbuse(boolean abuse) {
		this.abuse = abuse;
	}
	
	public int getGame() {
		return game;
	}
	public void addGame() {
		game++;
	}
	
	public int getUpset() {
		return upset;
	}
	public void addUpset() {
		upset++;
	}
	public boolean isMatched() {
		return matched;
	}
	public void setMatched(boolean matched) {
		this.matched = matched;
	}
	public User2(int id, int grade) {
		super();
		this.id = id;
		this.grade = grade;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public int getGrade() {
		return grade;
	}
	public void setGrade(int grade) {
		if(grade >= 10000) {
			grade = 9999;
		}else if(grade < 1) {
			grade = 1;
		}
		this.grade = grade;
	}
	public void addGrade(int score) {
		grade += score;
		if(grade >= 10000) {
			grade = 9999;
		}else if(grade < 1) {
			grade = 1;
		}
	}
	
	public int getFrom() {
		return from;
	}
	public void setFrom(int from) {
		this.from = from;
	}
	@Override
	public int compareTo(User2 o) {
		return this.grade - o.grade;
	}
	
	public int getStart() {
		return grade-300-from*50;
	}
	public int getEnd() {
		return grade+300+from*50;
	}
	
}
