import org.json.JSONObject;

public class Main {
    public static void main(String[] args) {



        RestAPI.callApi(new JSONObject(), "PUT");


    }
}
