import java.util.*;

public class No1 {

	public static void main(String[] args) {
		
		Solution1 sol = new Solution1();
		int[] s = {1, 0, 0, 1, 1,0,0,0,0,0,0,0,0,0,0,0,0,0};
		
		int answer  = sol.solution(s, 2);
		
		System.out.println(answer);
		
	}
	
	
	
}

class Solution1 {
    public int solution(int[] student, int k) {
        int answer = 0;
        
        int numOfSenior = 0;
        
        for (int i = 0; i < student.length; i++) {
			if(student[i]==1)numOfSenior++;
		}
        
        int[] left = new int[numOfSenior];        
        int[] right = new int[numOfSenior];        
        
        int num = 0;
        int idx = 0;
        for (int i = 0; i < student.length; i++) {
			if(student[i] == 1) {
				left[idx] = num;
				if(idx!=0) right[idx-1] = num;
				idx++;
				num = 0;
			}else {
				num++;
			}
		}
        right[numOfSenior-1] = num;
        
        
        int l = 0;
        int r = k-1;
        for (int i = 0; i < numOfSenior-k+1; i++) {
			answer += (left[l++]+1) * (right[r++]+1);
		}
        
        
        return answer;
    }
    
    
    
}