import java.util.*;

public class No2 {

	public static void main(String[] args) {
		
		Solution2 sol = new Solution2();
		String[] c = {"yxxy", "xxyyy", "yz", "aaa","aaa","aaa","aaa"};
		String answer  = sol.solution(c, 2, 1);
		System.out.println(answer);
		
	}
	
	
	
}


class Solution2 {
    public String solution(String[] research, int n, int k) {
        String answer = "";
        
        int[] numOfSearchSector = new int[26];
        int[][] numOfSearch = new int[research.length][26];
        int[] streak = new int[26];
        int[] numOfHot = new int[26];
        
        for (int day = 0; day < research.length; day++) {
			
        	for(int i=0;i<research[day].length();i++) {
				numOfSearch[day][research[day].charAt(i)-'a']++;
			}
        	
        	for (int i = 0; i < 26; i++) {
				if(numOfSearch[day][i] >= k) {
					streak[i]+=1;
				}else {
					streak[i] = 0;
				}
				numOfSearchSector[i] += numOfSearch[day][i];
				if(day >= n) {
					numOfSearchSector[i] -= numOfSearch[day-n][i];
				}
			}
        	
        	for (int i = 0; i < 26; i++) {
				if(streak[i] >= n && numOfSearchSector[i] >= 2*n*k) {
					numOfHot[i]++;
				}
			}
        	
		}
        
        char hot = 'A';
        int numHot = 0;
        
        for (int i = 0; i < 26; i++) {
			if(numOfHot[i] > numHot) {
				hot = (char) (i+'a');
				numHot = numOfHot[i];
			}
		}
        
        if(hot == 'A') return "None";
        
        return Character.toString(hot);
    }
}