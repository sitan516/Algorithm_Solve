import java.util.*;

public class No3 {

	public static void main(String[] args) {
		
		Solution3 sol = new Solution3();
		int[][] j = {{0, 2, 3, 1}, {101, 2, 4, 1}, {102, 3, 3, 1}};
		int[] answer  = sol.solution(j);
		for (int i = 0; i < answer.length; i++) {
			System.out.println(answer[i]);
		}
		
	}
	
	
	
}


//jobs[요청시각][걸리는시간][분류번호][중요도]
class Solution3 {
    public int[] solution(int[][] jobs) {
        int[] answer = {};
        int[] sumOfImportance = new int[101];
        int[] sumOfTime = new int[101];    
        int[] numOfTask = new int[101];
        int leftTask = jobs.length;
        
        Queue<Integer> startTime = new LinkedList<Integer>();
        List<Integer> order = new ArrayList<Integer>();
        
        for (int i = 1; i < jobs.length; i++) {
			startTime.add(jobs[i][0]);
			startTime.add(jobs[i][1]);
			startTime.add(jobs[i][2]);
			startTime.add(jobs[i][3]);
			
			
			
		}
        
        
        int time = jobs[0][0];
        int current = jobs[0][2];
        sumOfTime[current] = jobs[0][1];
        sumOfImportance[current] = jobs[0][3];
        numOfTask[current] = 1;
        
        nextSort: while(leftTask!=0) {
        	
        	if(current != -1) {
        		time += sumOfTime[current];
        		leftTask -= numOfTask[current];
        		sumOfTime[current] = 0;
        		sumOfImportance[current] = 0;
        		numOfTask[current] = 0;        		
        	}
        	
        	
        	// 이 시간 까지 들어온 명령 가져오기
        	if(!startTime.isEmpty()) {
        		while(startTime.peek() <= time) {
        			int st = startTime.poll();
        			int dr = startTime.poll();
        			int sn = startTime.poll();
        			int imp = startTime.poll();
        			sumOfTime[sn] += dr;
        			sumOfImportance[sn] += imp;
        			numOfTask[sn]++;
        			if(startTime.isEmpty()) break;
        		}        		
        	}
        	
        	if(current == -1) {
        		int nextSort = -1;
        		int nextMaxImp = 0;
        		for (int i = 0; i < sumOfTime.length; i++) {
					if(nextMaxImp < sumOfImportance[i]) {
						nextSort = i;
						nextMaxImp = sumOfImportance[i];
					}
				}
        		current = nextSort;
        		continue nextSort;
        	}
        	
        	
        	// 들어왔나?
        	if(sumOfTime[current] != 0) {
        		continue nextSort;
        	}else {
        		order.add(current);
        		int nextSort = -1;
        		int nextMaxImp = 0;
        		for (int i = 0; i < sumOfTime.length; i++) {
					if(nextMaxImp < sumOfImportance[i]) {
						nextSort = i;
						nextMaxImp = sumOfImportance[i];
					}
				}
        		if(nextSort == -1) {
        			if(startTime.isEmpty())break;
        			time = startTime.peek();
        		}
        		current = nextSort;
        		continue nextSort;
        	}
        	
        	
        }
        
        List<Integer> answerList = new ArrayList<Integer>();
        
        int last = -1;
        for (Integer integer : order) {
			if(last != integer) {
				answerList.add(integer);
				last = integer;
			}
		}
        
        answer = new int[answerList.size()];
        
        for (int i = 0; i < answerList.size(); i++) {
			answer[i] = answerList.get(i);
		}
        
        return answer;
    }
}