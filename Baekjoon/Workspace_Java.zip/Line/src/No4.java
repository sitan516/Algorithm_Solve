import java.util.*;

public class No4 {

	public static void main(String[] args) {
		
		Solution4 sol = new Solution4();
		int[][] p = {{2,2,2,2,2,2,5,7,10,10}};
		int[][] q = {{12, 15, 17}};
		int[] answer  = sol.solution(50);
		for (int i = 0; i < answer.length; i++) {
			System.out.println(answer[i]);
		}
		
	}
	
	
	
}


// 같은 숫자는 바로 제거
// 작은 수 부터
// 더하는 건 큰 수 부터
// 2 2 2 2 2 2 5 7 10 10    
// 12 15 17 


class Solution4 {
	
	int[] leastPrime = new int[1000001];
	
    public int[] solution(int n) {
        int[] answer = new int[n];
        
        answer[0] = 1;
        sort(n, answer, 1);

        
        
        return answer;
    }
    
    public void sort(int n, int[] answer, int d) {
    	int p = getLeastPrime(n);
    	
    	
    	if(n!=p) {
    		sort(n/p, answer, d*p);    		
    	}else {
    		for (int i = 1; i < p; i++) {
				answer[i] = answer[i-1] + d;
			}
    		return;
    	}
    	for (int j = 0; j < p-1; j++) {
    		for (int i = 0; i < n/p; i++) {
    			answer[n/p+i+j*p] = answer[i+j*p] + d;
    		}
		}
    }
    
    public int getLeastPrime(int n) {
    	if(leastPrime[n] != 0) return leastPrime[n];
    	for (int i = 2; i <= n; i++) {
			if(n % i == 0) return i;
		}
    	return -1;
    }
    
}