import java.util.*;

public class No5 {

	public static void main(String[] args) {
		
		Solution sol = new Solution();
		String[] nicks = {"imhero111", "moneyman", "hero111", "imher1111", "hro111", "mmoneyman", "moneymannnn"};
		String[] emails = {"superman5@abcd.com", "batman432@korea.co.kr", "superman@abcd.com", "supertman5@abcd.com", "superman@erty.net", "batman42@korea.co.kr", "batman432@usa.com"};
		int answer  = sol.solution(nicks, emails);
		System.out.println(answer);
		
	}
	
	
	
}



class Solution {
    public int solution(String[] nicks, String[] emails) {
        int n = nicks.length;
        int[] root = new int[n];
        for (int i = 0; i < root.length; i++) {
			root[i] = i;
		}
        boolean[][] simNicks = new boolean[n][n];
        boolean[][] simEmails = new boolean[n][n];
        
        String[][] emailPart = new String[n][2];
        
        for (int i = 0; i < emailPart.length; i++) {
			emailPart[i] = emails[i].split("@");
		}
        
        for (int i = 0; i < nicks.length; i++) {
			for (int j = i+1; j < nicks.length; j++) {
				if(isSimilarNick(nicks[i], nicks[j], 2)) {
					simNicks[i][j] = true;
					simNicks[j][i] = true;
				}
			}
		}
        
        for (int i = 0; i < n; i++) {
			for (int j = i+1; j < n; j++) {
				
				if(emailPart[i][1].equals(emailPart[j][1])) {
					if(isSimilarNick(emailPart[i][0], emailPart[j][0], 1)) {
						simEmails[i][j] = true;
						simEmails[j][i] = true;
						continue;
					}
				}
				
				if(emailPart[i][0].equals(emailPart[j][0])) {
					simEmails[i][j] = true;
					simEmails[j][i] = true;
				}
			}
		}
        
        for (int i = 0; i < n; i++) {
			for (int j = i+1; j < n; j++) {
				if(simNicks[i][j] && simEmails[i][j]) {
					union(i,j,root);
				}
			}
		}
        
        int dup = 0; // 중복수
        int cnt = 0; // 갯수
        Set<Integer> unique = new HashSet<Integer>();
        Set<Integer> set = new HashSet<Integer>();
        for (int i = 0; i < n; i++) {
			if(set.contains(root[i])) {
				unique.remove(root[i]);
				dup++;
				continue;
			}
			set.add(root[i]);
			unique.add(root[i]);
			cnt++;
		}
        
        return unique.size();
    }
    
    int find(int x, int[] root) {
        if (root[x] == x) {
            return x;
        } else {
            return find(root[x], root);
        }
    }

    void union(int x, int y, int[] root){
        x = find(x, root);
        y = find(y, root);
        root[y] = x;
    }
   
    
    public boolean isSimilarNick(String a, String b, int n) {
    	boolean ret = false;
    	if(n==-1) return false;
    	if(a.equals(b)) return true;
    	
    	int longer = -1;
    	if(a.length()>b.length()) longer= 1;
    	else if(b.length()> a.length()) longer = 2;
    	else longer = 0;
    	
    	int len = Math.min(a.length(), b.length());
    	if(Math.abs(a.length() - b.length()) > 2) {
    		return false;
    	}
    	
    	for (int i = 0; i < len-1; i++) {
			if(a.charAt(i) != b.charAt(i)) {
				if(longer == 1) {
					if(isSimilarNick(a.substring(i+1), b.substring(i), n-1)) {
						return true;
					}
				} else if(longer == 2) {
					if(isSimilarNick(a.substring(i), b.substring(i+1), n-1)) {
						return true;
					}
				} else {
					if(isSimilarNick(a.substring(i+1), b.substring(i), n-1)) {
						return true;
					}
					if(isSimilarNick(a.substring(i), b.substring(i+1), n-1)) {
						return true;
					}
				}
			}
		}
    	return ret;
    }
}





