import java.util.*;

public class No1 {

	public static void main(String[] args) {
		
		Solution1 sol = new Solution1();
		int[][] c = {{2,1,6,5,4,3}, {0,9,8,3,2,1}, {7,8,9,4,5,6}, {5,6,7,8,9,1}};
		int answer  = sol.solution(c);
		System.out.println(answer);
	}
	
	
	
}

class Solution1 {
	
    public int solution(int[][] dice) {
        int answer = 1;
        
        PriorityQueue<Integer> pq = new PriorityQueue<Integer>();
        
        int N = dice.length;
        
        add(0, 0, dice, pq, N,0);
        
        while(!pq.isEmpty()) {
        	int poll = pq.poll();
        	
        	if(answer < poll) break;
        	else if(answer == poll) answer++;
        }
        
        return answer;
    }
    
    
    
    void add(int depth, int num, int[][] dice, PriorityQueue<Integer> pq, int N, int bitmask) {
    	pq.add(num);
    	if(N == depth) {
    		return;
    	}
    	
    	for (int d = 0; d < N; d++) {
    		if((bitmask & (1 << d)) != 0) continue;
    		
    		for (int i = 0; i < 6; i++) {
//    			if(dice[d][i] == 0 && num == 0) continue;
    			add(depth+1,(int) (num + dice[d][i]*Math.pow(10, depth)), dice, pq, N, bitmask | 1<<d);
    		}
		}
    	
    }
    
}