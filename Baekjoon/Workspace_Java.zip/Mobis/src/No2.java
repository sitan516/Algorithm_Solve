import java.util.*;

public class No2 {

	public static void main(String[] args) {
		
		Solution2 sol = new Solution2();
		String[] c = {"abab", "bbaa", "bababa", "bbbabababbbaa"};
		boolean[] answer  = sol.solution(c);
		for (int i = 0; i < answer.length; i++) {
			System.out.println(answer[i]);
		}
		
	}
	
	
	
}

// 앞 뒤가 다르면 a를 뺀다.
// 앞 뒤가 둘다 b면 b를 뺀다.
// 앞 뒤가 둘다 a면 둘다 해본다.

class Solution2 {
	
    public boolean[] solution(String[] a) {
        boolean[] answer = new boolean[a.length];
        for (int i = 0; i < a.length; i++) {
        	answer[i] = canMake(a[i]);
		}
        return answer;
    }
    
    public boolean canMake(String s) {
        
    	int numA = 0;
    	
    	for (int i = 0; i < s.length(); i++) {
			if(s.charAt(i) == 'a') numA++;
		}
    	
        int front = 0;
        int back = s.length()-1;

        while(true) {
            if(front == back && s.charAt(front) == 'a') {
                return true;
            }else if(numA == 0) {
            	return false;
            }
            char frontChar = s.charAt(front);   
            char backChar = s.charAt(back);

            if(frontChar != backChar) {
                if(frontChar == 'a') {
                	numA--;
                    front++;
                }else {
                	numA--;
                    back--;
                }
            } else if(frontChar == 'b') {
                for (int i = 0; i < numA; i++) {
                	if(s.charAt(front) != 'b') return false;
                	if(s.charAt(back) != 'b') return false;
                	front++;
                	back--;
				}
            	
            } else if(frontChar == 'a') {
                front++;
                numA--;
            }

        }

    }
}