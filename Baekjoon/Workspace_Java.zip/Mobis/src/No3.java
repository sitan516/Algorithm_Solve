import java.util.*;

public class No3 {

	public static void main(String[] args) {
		
		Solution3 sol = new Solution3();
		int[] m = {3};
		int[] b = {15,15,15};
		int[] answer  = sol.solution(m,b);
		for (int i = 0; i < answer.length; i++) {
			System.out.println(answer[i]);
		}
		
	}
	
	
	
}

// 1111
// 1111
// 1111

// 010
// 가장 빠르게 바꿀 수 있는 녀석을 찾자.

class Solution3 {
    public int[] solution(int[] m, int[] b) {
        int[] answer = new int[m.length];
        int idx = 0;
        int[] pow2 = new int[32];
        pow2[0] = 1;
        for (int i = 1; i < pow2.length; i++) {
			pow2[i] = pow2[i-1] * 2;
		}
        
        
        
        for (int i = 0; i < m.length; i++) {
			int[] a = new int[m[i]];
			
			for (int j = 0; j < a.length; j++) {
				a[j] = b[idx++];
			}
			int andResult;
			int cnt = 0;
			while(true) {
				
				// 줄일 자릿수 찾기
				andResult = a[0]; 
				for (int j = 0; j < a.length; j++) {
					andResult &= a[j];
				}
				
				if(andResult == 0) {
					break;
				}
				
				String binary = Integer.toBinaryString(andResult);
				int len = binary.length();
				int powTwo = pow2[len-1];
				
				// 줄일 녀석 찾기
				int findIdx = -1;
				int findMin = Integer.MAX_VALUE;
				for (int j = 0; j < a.length; j++) {
					if(findMin > a[j] % powTwo) {
						findIdx = j;
						findMin = a[j] % powTwo;
					}
				}
				
				
				// 줄이기
				a[findIdx] -= (findMin+1);
				cnt += (findMin+1);
			}
        	answer[i] = cnt;
		}
        
        
        return answer;
    }
}