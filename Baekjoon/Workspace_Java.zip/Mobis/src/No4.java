import java.util.*;

public class No4 {

	public static void main(String[] args) {
		
		Solution sol = new Solution();
		int[][] p = {{2,2,2,2,2,2,5,7,10,10}};
		int[][] q = {{12, 15, 17}};
		boolean[] answer  = sol.solution(p, q);
		for (int i = 0; i < answer.length; i++) {
			System.out.println(answer[i]);
		}
		
	}
	
	
	
}


// 같은 숫자는 바로 제거
// 작은 수 부터
// 더하는 건 큰 수 부터
// 2 2 2 2 2 2 5 7 10 10    
// 12 15 17 


class Solution {
    public boolean[] solution(int[][] p, int[][] q) {
        boolean[] answer = new boolean[p.length];
        
//        PriorityQueue<Integer> pqP = new PriorityQueue<>(Collections.reverseOrder());
        List<Integer> listP = new ArrayList<Integer>();
        PriorityQueue<Integer> pqQ = new PriorityQueue<Integer>();
        
        newTest : for (int test = 0; test < p.length; test++) {
        	listP.clear();
        	pqQ.clear();
        	
        	for (int i = 0; i < p[test].length; i++) {
        		listP.add(p[test][i]);
			}
        	listP.sort((o1,o2) -> o2-o1);
        	for (int i = 0; i < q[test].length; i++) {
        		pqQ.add(q[test][i]);
			}
        	
        	int bitmask = 0;
        	while(!pqQ.isEmpty()) {
        		int target = pqQ.poll();
        		
        		List<Integer> sumList = getIdealMember(target, listP, bitmask, 0);
        		
        		if(sumList == null) {
        			answer[test] = false;
        			continue newTest;
        		}
        		
        		nextInt: for (Integer integer : sumList) {
        			for (int i = 0; i < listP.size(); i++) {
						if(listP.get(i) == integer && (bitmask & 1<<i) == 0) {
							bitmask |= 1<<i;
							continue nextInt;
						}
					}
				}
        	}
        	
        	answer[test] = true;
        	
		}
        
        
        return answer;
    }

	private List<Integer> getIdealMember(int target, List<Integer> listP, int bitmask, int start) {
		
		List<Integer> ret = new ArrayList<Integer>();
		
		for (int i = start; i < listP.size(); i++) {
			if((bitmask & 1<<i) != 0) continue;
			
			if(target == listP.get(i)) {
				ret.add(listP.get(i));
				return ret;
			}else if(target > listP.get(i)) {
				ret.add(listP.get(i));
				List<Integer> temp = getIdealMember(target-listP.get(i), listP, bitmask | 1<<i, i+1);
				if(temp == null) {
					return null;
				} else {
					ret.addAll(temp);
					return ret;
				}
			}
		}
		
		
		
		return null;
	}
}