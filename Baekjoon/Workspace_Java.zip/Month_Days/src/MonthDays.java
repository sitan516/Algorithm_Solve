import java.util.Scanner;

public class MonthDays {
	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in); 
		
		int[] days = {31,28,31,30,31,30,31,31,30,31,30,31};
		
		while(true) {
			System.out.print("�� : ");
			int year = sc.nextInt();
			System.out.print("�� : ");
			int month = sc.nextInt();
			
			int day = days[month-1];
			if(month == 2) {
				if((year % 4 == 0) && (year % 100 != 0) || (year % 400) == 0) {
					day++;
				}
			}
			System.out.println(year + "�� " + month + "���� " + day + "�ϱ��� �ֽ��ϴ�.");
			
			
		}
		
	}
}
