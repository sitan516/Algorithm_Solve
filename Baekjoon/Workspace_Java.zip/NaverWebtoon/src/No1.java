import java.util.Arrays;

public class No1 {

	public static void main(String[] args) {
		
		Solution1 sol = new Solution1();
		int[] v = {13000, 88000, 10000};
		int[] c = {30, 50,50,100};
		int answer  = sol.solution(v,c);
		System.out.println(answer);
	}
	
	
	
}

class Solution1 {
    public int solution(int[] prices, int[] discounts) {
        int answer = 0;
        
        Arrays.sort(prices);
        Arrays.sort(discounts);
        int d_idx = discounts.length-1;
        
        for (int i = prices.length-1; i >= 0; i--) {
        	if(d_idx >= 0) {
        		answer += prices[i] *(100 - discounts[d_idx--]) / 100;        		
        	} else {
        		answer += prices[i];
        	}
		}
        
        return answer;
    }
}