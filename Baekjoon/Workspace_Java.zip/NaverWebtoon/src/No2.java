import java.util.*;

public class No2 {

	public static void main(String[] args) {
		
		Solution2 sol = new Solution2();
		int[] v = {13000, 88000, 10000};
		int[] c = {30, 20};
		String[] answer  = sol.solution("abcxyqwertyxyabc");
		for (int i = 0; i < answer.length; i++) {
			System.out.println(answer[i]);			
		}
	}
	
	
	
}

//aabaab

class Solution2 {
    public String[] solution(String s) {
        
        
        List<String> list = new LinkedList<String>();
        
        StringBuilder front = new StringBuilder();
        StringBuilder back = new StringBuilder();
        
        for (int i = 0; i < s.length()/2; i++) {
			front.append(s.charAt(i));
			back.insert(0,s.charAt(s.length()-1-i));
			if(front.toString().equals(back.toString())) {
				list.add(front.toString());
				front.delete(0, front.length());
				back.delete(0, back.length());
			}
		}
        
        int iterStart = list.size()-1;
        
        // Ȧ�� ó��
        if(s.length() % 2 == 1) {
        	list.add(front.toString() + s.charAt(s.length()/2) + back.toString());
        	front.delete(0, front.length());
			back.delete(0, back.length());
        }
        
        // ��� �ܾ� ó��
        if(front.length()>0) {
        	list.add(front.toString() + back.toString());
        }
        
        // �յ� �Ȱ���
        for (int i = iterStart; i >= 0; i--) {
			list.add(list.get(i));
		}
        
        String[] answer = new String[list.size()];
        for (int i = 0; i < answer.length; i++) {
			answer[i] = list.get(i);
		}
        
        return answer;
    }
}