import java.util.*;

public class No3 {

	public static void main(String[] args) {
		
		Solution sol = new Solution();
		int answer  = sol.solution("asdasdffasdfasdfasaasdfsasdfdfdaasdfsdasdasdffff", "asdf");
		System.out.println(answer);
		
	}
}



class Solution {
    public int solution(String s, String t) {
		int answer = 0;
		char lastT = t.charAt(t.length()-1);
		Stack<Character> stack = new Stack<Character>();
		
		for (int i = 0; i < s.length(); i++) {
			stack.push(s.charAt(i));
			
			if(s.charAt(i) == lastT) {
				Stack<Character> temp = new Stack<Character>();
				for (int j = t.length()-1; j >= 0; j--) {
					if(!stack.isEmpty()&&stack.peek() == t.charAt(j)) {
						temp.push(stack.pop());
					} else {
						while(!temp.isEmpty()) {
							stack.push(temp.pop());
						}
						break;
					}
				}
				answer++;
			}
			
		}
		

		
		return answer;
    }
}