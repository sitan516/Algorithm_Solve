import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.StringTokenizer;

public class Solution{
	
	static int N;
	static int answer;
	static int[] station;
	
	public static void main(String args[]) throws Exception{
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		StringTokenizer st;
		
		int T = Integer.parseInt(br.readLine());
		
		// 20C4 = 116280 
		// 그냥 완탐해도 됨
		
		for (int tc = 1; tc <= T; tc++) {
			answer = 0;
			N = Integer.parseInt(br.readLine());
			st = new StringTokenizer(br.readLine());
			station = new int[N];
			for (int i = 0; i < N; i++) {
				station[i] = Integer.parseInt(st.nextToken());
			}
			getCombination(0,0,0);
			System.out.println("#"+tc+" "+answer);
		}
	}
	
	public static void getCombination(int cnt, int idx, int bitmask) {
		if(cnt == 4) {
			getAvailablity(bitmask);
			return;
		}
		
		for (int i = idx; i < N; i++) {
			getCombination(cnt+1, i+1, bitmask | 1<<i);
		}
	}
	
	public static void getAvailablity(int bitmask) {
		int max = 0;
		
		// 숫자 4개 받아오기
		int idx = 0;
		int[] nums = new int[4];
		for (int i = 0; i < N; i++) {
			if((bitmask & 1 << i) != 0) {
				nums[idx++] = i;
			}
		}
		
		// 하나에 두 개의 직통이 있으면 안됨 => 이미 해결
		
		// 인접한 두 역을 이으면 안됨
		// 인접한 두 역에 직통을 둘 다 놓으면 안됨  => 모든 숫자들 사이가 2이상 이어야함
		for (int i = 1; i < 4; i++) {
			if(nums[i] - nums[i-1] == 1) {
				return ;
			}
		}
		if(nums[3] - nums[0] == N-1) return;
		
	
		
		// 교차하면 안됨 => 숫자 4개가 12, 34 / 14,23 으로 직통이 되어야 함
		max = (station[nums[0]] + station[nums[1]]) *
				(station[nums[0]] + station[nums[1]]) +
				(station[nums[2]] + station[nums[3]]) *
				(station[nums[2]] + station[nums[3]]);
				
		
		max = Math.max(max, (station[nums[0]] + station[nums[3]]) *
				(station[nums[0]] + station[nums[3]]) +
				(station[nums[2]] + station[nums[1]]) *
				(station[nums[2]] + station[nums[1]]));
		
		
		answer = Math.max(max, answer);
	}
	
	
 }
