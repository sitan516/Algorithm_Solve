import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.StringTokenizer;

public class Solution2{
	
	static int[][] board;
	static int N;
	static boolean[][] canCatch;
	static int[] dy = {1,-1,0,0}; 
	static int[] dx = {0,0,1,-1}; 
	
	
	public static void main(String args[]) throws Exception{
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		StringTokenizer st;
		
		int T = Integer.parseInt(br.readLine());
		
		for (int tc = 1; tc <= T; tc++) {
			
			// 입력
			
			N = Integer.parseInt(br.readLine());
			board = new int[N][N];
			canCatch = new boolean[N][N];
			
			int R = -1;
			int C = -1;
			
			for (int r = 0; r < N; r++) {
				st = new StringTokenizer(br.readLine());
				for (int c = 0; c < N; c++) {
					board[r][c] = Integer.parseInt(st.nextToken());
					if(board[r][c] == 2) {
						R = r; C = c;
					}
				}
			}
			
			// DFS로 풀어야함
			// depth가 3이니까 백트래킹 안함
			DFS(1,R,C);
			int answer = 0;
			for (int r = 0; r < N; r++) {
				for (int c = 0; c < N; c++) {
					if(canCatch[r][c]) answer++;
				}
			}
			System.out.println("#"+tc+" "+answer);
			
		}
	}
	
	static void DFS(int depth, int r, int c) {
		if(depth > 3) {
			return;
		} 
			
		for (int dir = 0; dir < 4; dir++) {
			boolean jump = false;
			int len = 1;
			
			while(true) {
				int newR = r + dy[dir] * len;
				int newC = c + dx[dir] * len;
				if(newR >= N || newC >= N || newR < 0 || newC < 0) {
					break;
				}
				if(board[newR][newC] == 1) {
					if(jump) {
						canCatch[newR][newC] = true;
						board[newR][newC] = 2;
						board[r][c] = 0;
						DFS(depth+1, newR, newC);
						board[newR][newC] = 1;
						board[r][c] = 2;
						break;
					} else {
						jump = true;
					}
					
				}else {
					if(jump) {
						board[newR][newC] = 2;
						board[r][c] = 0;
						DFS(depth+1, newR, newC);
						board[newR][newC] = 0;
						board[r][c] = 2;
					}else {
						;;
					}
				}
				len++;
				
			}

		}
			
			
		
	}
	
	
 }
