import java.util.*;

public class No2 {

	public static void main(String[] args) {
		
		Solution2 sol = new Solution2();
		int[] v = {13000, 88000, 10000};
//		int[] c = {30, 20};
		int[] requests = {1,2,2,3,4,1};
		
		int[][] answer  = sol.solution(2, true, requests);
		
		for (int r = 0; r < answer.length; r++) {
			for (int c = 0; c < answer[0].length; c++) {
				System.out.println(answer[r][c]);
			}
		}
	}
	
	
	
}


class Solution2 {
    public int[][] solution(int servers, boolean sticky, int[] requests) {
        
        List<Integer> server[] = new ArrayList[servers];
        for (int i = 0; i < server.length; i++) {
			server[i] = new ArrayList<Integer>();
		}
        if(sticky) {
        	int serverSize[] = new int[servers];
        	Map<Integer, Integer> map = new HashMap<Integer, Integer>();
        	
        	for (int i = 0; i < requests.length; i++) {
				if(map.containsKey(requests[i])){
					server[map.get(requests[i])].add(requests[i]);
					serverSize[map.get(requests[i])]++;
				} else {
					int target = getLeastSizeServer(serverSize);
					map.put(requests[i], target);
					server[map.get(requests[i])].add(requests[i]);
					serverSize[target]++;
				}
			}
        	int[][] answer = new int[servers][serverSize[0]];
        	
        	for (int i = 0; i < servers; i++) {
        		int index = 0;
        		for (int req : server[i]) {
        			answer[i][index] = req;
        		}
        	}
        	return answer;
        	
        }else {
        	
        	
        	int index = 0;
        	for (int request : requests) {
				server[index++].add(request);
				if(index > servers) index = 0;
			}
        	
    		int[][] answer = new int[servers][requests.length/servers];
        	
        	for (int i = 0; i < servers; i++) {
        		int idx = 0;
        		for (int req : server[i]) {
        			answer[i][idx] = req;
        		}
        	}
        	return answer;
        }
        
        
        
        
    }
    
    int getLeastSizeServer(int[] serverSize){
    	int min = Integer.MAX_VALUE;
    	int idx = -1;
    	for (int i = 0; i < serverSize.length; i++) {
			if(serverSize[i] < min) {
				min = serverSize[i];
				idx = i;
			}
		}
    	return idx;
    }
}