import java.util.Arrays;

public class No3 {

	public static void main(String[] args) {
		
		Solution3 sol = new Solution3();
		int[] v = {13000, 88000, 10000};
		int[] c = {30, 50,50,100};
		boolean answer  = sol.solution("1,,000");
		System.out.println(answer);
	}
	
	
	
}

class Solution3 {
    public boolean solution(String amountText) {
        boolean answer = true;
        boolean comma = false;
        
        for (char c : amountText.toCharArray()) {
			if((c >= '0' && c <= '9')) {
				continue;
			}else if(c == ','){
				comma = true;
				continue;
			}	
			else {
				return false;
			}
		}
        
        if(amountText.charAt(0) == '0' && amountText.length() > 1) {
        	return false;
        }
        
        if(amountText.charAt(0) == ',') {
        	return false;
        }
        
        if(comma) {
        	int num = 0;
        	for (int i = amountText.length()-1; i >= 0; i--) {
        		char c =amountText.charAt(i);
        		if((c >= '0' && c <= '9')) {
        			if(num==3) {
        				return false;
        			}
        			num++;
        			
    				continue;
    			} else {
    				if(num == 3) {
    					num = 0;
    					continue;
    				} else {
    					return false;
    				}
    			}
        	}        	
        }
        
        
        
        
        return true;
    }
}