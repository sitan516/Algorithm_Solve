import java.util.Arrays;
import java.util.LinkedList;
import java.util.Queue;
import java.util.StringTokenizer;

public class No4 {

	public static void main(String[] args) {
		
		Solution4 sol = new Solution4();
		
		String answer  = sol.solution("1 2\r\n" + 
				"SHOW\r\n" + 
				"SHOW\r\n" + 	
				"SHOW\r\n" + 	
				"NEXT\r\n" + 	
				"SHOW\r\n" + 	
				"NEXT\r\n" + 	
				"SHOW\r\n" + 
				"NEGATIVE\r\n" + 	
				"SHOW\r\n" + 	
				"EXIT\r\n");
		System.out.println(answer);
	}
	
	
	
}

class Solution4 {
    public String solution(String input) {
        String answer = "";
        StringBuilder sb = new StringBuilder();
        StringTokenizer st = new StringTokenizer(input, "\n");
        
        StringTokenizer firstLine = new StringTokenizer(st.nextToken());
        int M = Integer.parseInt(firstLine.nextToken());
        int N = Integer.parseInt(firstLine.nextToken());
        
        int sum = 0; // M�ϵ��� ���� Ƚ��
        Queue<Integer> q = new LinkedList<Integer>(); 
        int day = 0;
        int showToday = 0;
        boolean negative = false;
        int negativeDay = -1;
        
        sb.append(M).append(" ").append(N).append("\n");
        while(st.hasMoreTokens()) {
        	String req = st.nextToken().trim();
        	
        	if(req.equals("SHOW")) {
        		if(sum < N && !negative) {
        			sb.append(1).append("\n");
        			showToday++;
        			sum++;
        			if(sum == N) {
        				negative = true;
        				negativeDay = day;	
        			}
        		} else {
        			sb.append(0).append("\n");
        		}
        		
        	} else if(req.equals("NEXT")) {
        		q.offer(showToday);
        		if(day >= M-1) {
        			sum -= q.poll();        			
        		}
        		showToday = 0;
        		day++;
        		
        		if(negative) {
        			if(day - negativeDay > M) {
        				negative = false;
        			}
        		}
        		sb.append("-").append("\n");
        		
        	} else if(req.equals("EXIT")) {
        		sb.append("BYE");
        		break;
        	} else if(req.equals("NEGATIVE")) {
        		negative = true;
        		negativeDay = day;
        		sb.append(0).append("\n");
        	} else {
        		sb.append("ERROR").append("\n");
        	}
        	
        }
        
        
        return sb.toString();
    }
}