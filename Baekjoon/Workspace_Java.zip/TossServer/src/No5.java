import java.util.*;

public class No5 {

	public static void main(String[] args) {
		
		Solution5 sol = new Solution5();
//		int[] v = {13000, 88000, 10000};
		int[] c = {1,2,3,4,5};
		int[] answer  = sol.solution(c,2);
		for (int i = 0; i < answer.length; i++) {
			System.out.println(answer[i]);			
		}
	}
	
	
	
}

class Solution5 {
    public int[] solution(int[] fruitWeights, int k) {
        Set<Integer> answer = new HashSet<Integer>();
        Queue<Integer> q = new LinkedList<>();
        
        int max = 0;
        for (int i = 0; i < fruitWeights.length; i++) {
			if(q.size() < k) {
				q.offer(fruitWeights[i]);
				max = Math.max(fruitWeights[i], max);
			} else {
				q.offer(fruitWeights[i]);
				if(max < fruitWeights[i]) {
					max = fruitWeights[i];
					q.poll();
				}else if(max == q.poll()) {
					max = 0;
					for (Integer integer : q) {
						max = Math.max(integer, max);
					}
				}
			}
			if(q.size() == k) {
				answer.add(max);
			}
		}
        
        Integer[] answerArr = new Integer[answer.size()];
        int idx = 0;
        for (Integer i : answer) {
			answerArr[idx++] = i;
		}
        Arrays.sort(answerArr, (o1,o2) ->o2-o1);
        
        int[] a = new int[answer.size()];
        for (int i = 0; i < a.length; i++) {
			a[i] = answerArr[i];
		}
        
        return a;
    }
}